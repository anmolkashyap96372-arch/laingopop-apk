# LaingoPop APK banane ke steps (PC par, Node.js chahiye)

1. Is folder me terminal kholo:
   npm install
   npx cap add android
2. Alarm sound copy karo:
   android-res-raw/alarm.wav  ->  android/app/src/main/res/raw/alarm.wav   (raw folder banana pade to bana lo)
3. android/app/src/main/AndroidManifest.xml me <manifest> ke andar ye permissions daalo:
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
   <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
   <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
   <uses-permission android:name="android.permission.VIBRATE"/>
4. npx cap sync android
5. npx cap open android   -> Android Studio me: Build > Build APK(s)
6. APK phone me install karo, app kholo, notification + "Alarms & reminders" permission Allow karo.
7. Phone: Settings > Apps > LaingoPop > Battery > Unrestricted, Auto-launch ON.
