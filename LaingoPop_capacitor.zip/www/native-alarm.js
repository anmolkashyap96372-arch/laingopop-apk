/* LaingoPop native alarm bridge — sirf Capacitor (Android APK) me kaam karta hai, browser me kuch nahi karta */
(function(){
  var C=window.Capacitor;
  var isNative=!!(C&&C.isNativePlatform&&C.isNativePlatform());
  if(!isNative){window.NativeAlarm=null;return;}
  var API_BASE='https://laingopop-cuka.onrender.com'; // apna Render server
  // 1) /api/... calls ko Render server par bhejo (APK me Netlify redirect nahi hota)
  var _f=window.fetch.bind(window);
  window.fetch=function(u,o){
    try{
      var s=typeof u==='string'?u:(u&&u.url)||'';
      var x=new URL(s,location.href);
      if(x.origin===location.origin&&x.pathname.indexOf('/api/')===0){u=API_BASE+x.pathname+x.search}
    }catch(e){}
    return _f(u,o);
  };
  var LN=function(){return C.Plugins&&C.Plugins.LocalNotifications};
  var CH='laingopop-alarm-v1';
  var ready=null;
  function init(){
    if(ready)return ready;
    ready=(async function(){
      var L=LN();if(!L)return false;
      try{
        var p=await L.checkPermissions();
        if(p.display!=='granted')p=await L.requestPermissions();
        try{var ex=await L.checkExactNotificationSetting();if(ex&&ex.exact_alarm!=='granted'){await L.changeExactNotificationSetting()}}catch(e){}
        await L.createChannel({id:CH,name:'Vocabulary alarm',description:'Word quiz reminders',importance:5,visibility:1,sound:'alarm.wav',vibration:true,lights:true});
        L.addListener('localNotificationActionPerformed',function(){
          var t=0,i=setInterval(function(){
            t++;
            if(typeof startQuiz==='function'&&S&&S.words&&S.words.length&&!window.quizOpen){clearInterval(i);try{startQuiz()}catch(e){}}
            if(t>20)clearInterval(i);
          },300);
        });
        return p.display==='granted';
      }catch(e){return false}
    })();
    return ready;
  }
  function parse(t,dayOffset){
    var m=/^(\d{1,2}):(\d{2})$/.exec(t||'');if(!m)return null;
    var d=new Date();d.setDate(d.getDate()+dayOffset);d.setHours(+m[1],+m[2],0,0);return d;
  }
  // opts: {on, todayTimes[], fixedTimes[]|null, title, body()}
  async function sync(opts){
    var ok=await init();if(!ok)return;var L=LN();
    try{
      var pend=await L.getPending();
      if(pend&&pend.notifications&&pend.notifications.length)await L.cancel({notifications:pend.notifications.map(function(n){return{id:n.id}})});
    }catch(e){}
    if(!opts||!opts.on)return;
    var now=Date.now(),list=[],id=1;
    var days=opts.fixedTimes&&opts.fixedTimes.length?7:1;
    for(var d=0;d<days;d++){
      var times=(opts.fixedTimes&&opts.fixedTimes.length)?opts.fixedTimes:(d===0?opts.todayTimes:[]);
      (times||[]).forEach(function(t){
        var at=parse(t,d);if(!at||at.getTime()<=now+5000)return;
        list.push({id:id++,title:opts.title||'LaingoPop',body:(opts.body&&opts.body())||'A few words are waiting. Tap to answer.',
          channelId:CH,sound:'alarm.wav',schedule:{at:at,allowWhileIdle:true},autoCancel:true,ongoing:false});
      });
    }
    if(list.length)try{await L.schedule({notifications:list})}catch(e){}
  }
  window.NativeAlarm={sync:sync,init:init};
  document.addEventListener('DOMContentLoaded',function(){init()});

  // 2) WebView me 'Notification' API nahi hoti -> app "Not supported" dikhata tha. Shim laga do (permission native plugin se).
  var perm='default';
  function setPerm(v){perm=(v==='granted')?'granted':(v==='denied'?'denied':'default')}
  if(typeof window.Notification==='undefined'){
    var N=function(){};
    Object.defineProperty(N,'permission',{get:function(){return perm}});
    N.requestPermission=async function(){
      try{
        var L=LN();if(!L)return perm;
        var p=await L.requestPermissions();setPerm(p.display);
        try{var ex=await L.checkExactNotificationSetting();if(ex&&ex.exact_alarm!=='granted'){await L.changeExactNotificationSetting()}}catch(e){}
        window.NativeAlarm.resync();
      }catch(e){}
      return perm;
    };
    window.Notification=N;
  }
  (async function(){try{var L=LN();if(L){var p=await L.checkPermissions();setPerm(p.display)}}catch(e){}})();
  // 3) App ka baad wala syncSW native alarm ko skip karta tha -> wrap karke native sync hamesha chalao
  function nativeSync(){
    try{
      if(typeof S==='undefined'||!S||!S.alarm)return;
      sync({on:!!(S.alarm.on&&S.words&&S.words.length),todayTimes:todaysTimes(),
        fixedTimes:S.alarm.type==='fixed'?S.alarm.times.slice(0,S.alarm.count):null,
        title:(typeof remindTitle==='function'?remindTitle():'LaingoPop'),
        body:(typeof remindBody==='function'?remindBody:null)});
    }catch(e){}
  }
  window.NativeAlarm.resync=nativeSync;
  window.addEventListener('load',function(){
    setTimeout(function(){
      var orig=window.syncSW;
      window.syncSW=async function(){
        try{nativeSync()}catch(e){}
        try{if(orig)return await orig.apply(this,arguments)}catch(e){}
      };
      nativeSync();
    },500);
  });
})();
